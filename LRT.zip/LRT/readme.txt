Table 2:
1. BLRT2/simulation/efficiency2.py
2. BLRT2/analysis/efficiency2 (A).py

Classic log-rank test and Noninform
in Table 3 & Table 4 & Table S1 & Table S2:
1. BLRT2/simulation/null.py
2. BLRT2/analysis/null (A).py
3. BLRT2/simulation/non_null.py
4. BLRT2/analysis/non_null (A).py

Correct informative prior or Oracle prior
in Table 3 & Table 4 & Table S1 & Table S2:
1. BLRT3/simulation/weibull.py
2. BLRT3/analysis/weibull (A).py
3. BLRT3/simulation/twoline.py
4. BLRT3/analysis/twoline (A).py

Incorrectly informative prior
in Table 3 & Table S1:
1. BLRT3/simulation/weibull2.py
2. BLRT3/analysis/weibull2 (A).py
3. BLRT3/simulation/weibull3.py
4. BLRT3/analysis/weibull3 (A).py
5. BLRT3/simulation/twoline2.py
6. BLRT3/analysis/twoline2 (A).py
7. BLRT3/simulation/twoline3.py
8. BLRT3/analysis/twoline3 (A).py

Bayesian DPM test
in Table 3 & Table S1:
1. BLRT4/simulation/run_DPM.py
2. BLRT4/analysis/DPM_100.py

(a) and (b) and (c)
in Figure 1:
1. BLRT2/simulation/null.py
2. BLRT2/analysis/null (A).py

(d) and (e) and (f)
in Figure 1:
1. BLRT2/simulation/null_gu.py

Unit information prior
in Table 4 & Table S2:
1. BLRT4/simulation/run_MDP_UIP.py
2. BLRT4/analysis/MDP_UIP_100.py

(b)
in Figure 2:
1. BLRT2/simulation/real_yin.py

Table 5:
1. BLRT2/simulation/real.py
2. BLRT2/analysis/real (A).py

